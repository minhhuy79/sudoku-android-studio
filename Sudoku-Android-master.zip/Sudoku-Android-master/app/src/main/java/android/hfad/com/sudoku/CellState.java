package android.hfad.com.sudoku;

/**
 * Created by tuana on 29-03-2018.
 */

public class CellState {
    int mask, index;
}
